package eu.kanade.tachiyomi.ui.manga.chapter

import android.content.Context
import android.view.MenuItem
import eu.davidea.flexibleadapter.FlexibleAdapter
import eu.kanade.tachiyomi.R
import eu.kanade.tachiyomi.data.preference.PreferencesHelper
import eu.kanade.tachiyomi.util.system.getResourceColor
import uy.kohesive.injekt.injectLazy
import java.text.DateFormat
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols

class ChaptersAdapter(
    controller: ChaptersController,
    context: Context
) : FlexibleAdapter<ChapterItem>(null, controller, true) {
    val preferences: PreferencesHelper by injectLazy()

    var items: List<ChapterItem> = emptyList()

    val readColor = context.getResourceColor(com.google.android.material.R.attr.colorOnSurface, 0.38f)
    val unreadColor = context.getResourceColor(com.google.android.material.R.attr.colorOnSurface)
    val menuItemListener: OnMenuItemClickListener = controller

    val bookmarkedColor = context.getResourceColor(androidx.appcompat.R.attr.colorAccent)

    val decimalFormat =
        DecimalFormat(
            "#.###",
            DecimalFormatSymbols()
                .apply { decimalSeparator = '.' }
        )

    val dateFormat: DateFormat = preferences.dateFormat()

    override fun updateDataSet(items: List<ChapterItem>?) {
        this.items = items ?: emptyList()
        super.updateDataSet(items)
    }

    fun indexOf(item: ChapterItem): Int {
        return items.indexOf(item)
    }

    interface OnMenuItemClickListener {
        fun onMenuItemClick(
            position: Int,
            item: MenuItem
        )
    }
}
